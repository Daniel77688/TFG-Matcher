#!/usr/bin/env python3
"""
Script para cargar datos CSV en ChromaDB
"""

from utils.data_processor import DataProcessor
import sys
import os

# Añadir el directorio padre al path para importar config
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def main():
    """Función principal para cargar los datos"""
    print("🚀 Iniciando carga de datos a ChromaDB")
    print("=" * 50)
    
    try:
        # Crear procesador de datos
        processor = DataProcessor()
        
        # Cargar datos
        collection = processor.load_data_to_chroma(batch_size=1000)
        
        if collection:
            print("\n✅ ¡Carga de datos completada exitosamente!")
            print(f"📊 Total documentos cargados: {collection.count()}")
            
            # Mostrar algunas estadísticas iniciales
            print("\n📈 Estadísticas iniciales:")
            print(f"   - Modelo de embeddings: {processor.model.get_sentence_transformer_spec()['model_name']}")
            print(f"   - Colección: {collection.name}")
            
        else:
            print("\n❌ Error en la carga de datos")
            sys.exit(1)
            
    except Exception as e:
        print(f"\n❌ Error durante la carga: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()