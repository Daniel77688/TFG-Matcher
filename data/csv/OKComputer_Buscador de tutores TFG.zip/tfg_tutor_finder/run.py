#!/usr/bin/env python3
"""
Script principal para ejecutar la aplicación TFG Finder
"""

import uvicorn
import os
from pathlib import Path

# Añadir el directorio actual al path para importar módulos
import sys
sys.path.append(str(Path(__file__).parent))

from config import API_HOST, API_PORT, API_RELOAD

def main():
    """Función principal para iniciar la aplicación"""
    print("🚀 Iniciando TFG Finder")
    print("=" * 50)
    
    # Verificar que existe el directorio de datos
    csv_dir = Path("data/csv")
    if not csv_dir.exists():
        print(f"⚠️  Advertencia: El directorio {csv_dir} no existe")
        print("   Por favor, coloca tus archivos CSV en data/csv/")
        print("   Luego ejecuta: python data_loader.py")
    else:
        csv_count = len(list(csv_dir.glob("*.csv")))
        print(f"📁 Encontrados {csv_count} archivos CSV")
    
    # Verificar que existe la base de datos
    chroma_dir = Path("chroma_db")
    if not chroma_dir.exists():
        print("⚠️  Advertencia: La base de datos ChromaDB no existe")
        print("   Ejecuta primero: python data_loader.py")
        print("   Para cargar los datos de los CSV")
    else:
        print("✅ Base de datos ChromaDB encontrada")
    
    print(f"\n🌐 Iniciando servidor en http://{API_HOST}:{API_PORT}")
    print("📱 Abre tu navegador y visita la aplicación")
    print("\n📋 Rutas disponibles:")
    print("   /              - Página principal")
    print("   /search-page   - Búsqueda de tutores")
    print("   /about         - Acerca de")
    print("   /docs          - Documentación API (Swagger)")
    print("\n" + "=" * 50)
    
    # Iniciar el servidor
    uvicorn.run(
        "app.main:app",
        host=API_HOST,
        port=API_PORT,
        reload=API_RELOAD,
        log_level="info"
    )

if __name__ == "__main__":
    main()