import os
from pathlib import Path

# Rutas del proyecto
BASE_DIR = Path(__file__).parent
CSV_DIR = BASE_DIR / "data" / "csv"
CHROMA_DIR = BASE_DIR / "chroma_db"
STATIC_DIR = BASE_DIR / "static"
TEMPLATES_DIR = BASE_DIR / "templates"

# Configuración de ChromaDB
COLLECTION_NAME = "profesores_tfg"
EMBEDDING_MODEL = "all-MiniLM-L6-v2"

# Configuración de la API
API_HOST = "0.0.0.0"
API_PORT = 8000
API_RELOAD = True

# Campos relevantes de los CSV
RELEVANT_FIELDS = [
    "TÍTULO",
    "AUTORES",  
    "FECHA",
    "IDENTIFICADOR",
    "TIPO",
    "TIPO DE PRODUCCIÓN",
    "CATEGORÍAS",
    "FUENTE",
    "IF SJR",
    "Q SJR"
]

# Tipos de producción para filtros
TIPOS_PRODUCCION = [
    "Docencia Oficial Nacional",
    "TFG", 
    "TFM",
    "Proyecto Competitivo",
    "Artículo",
    "Conferencia Publicada",
    "Tramo de Investigación (Sexenio)"
]

# Categorías académicas
CATEGORIAS_ACADEMICAS = [
    "Computer science",
    "Artificial intelligence", 
    "Machine learning",
    "Data science",
    "Statistics",
    "Mathematics",
    "Engineering"
]