from typing import List, Dict, Any, Optional
import json
from datetime import datetime
import re

class SearchEngine:
    def __init__(self, chroma_collection):
        self.collection = chroma_collection
        
    def search(self, query: str, limit: int = 10, filters: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Realiza búsqueda semántica con filtros opcionales
        """
        # Construir where_clause para ChromaDB
        where_clause = {}
        
        if filters:
            # Filtro por profesor
            if "profesor" in filters:
                where_clause["profesor"] = filters["profesor"]
            
            # Filtro por tipo de producción
            if "tipo_produccion" in filters:
                where_clause["tipo_produccion"] = filters["tipo_produccion"]
            
            # Filtro por cuartil SJR
            if "q_sjr" in filters:
                where_clause["q_sjr"] = filters["q_sjr"]
        
        # Realizar búsqueda en ChromaDB
        results = self.collection.query(
            query_texts=[query],
            n_results=limit,
            where=where_clause if where_clause else None,
            include=["metadatas", "documents", "distances"]
        )
        
        # Procesar resultados
        processed_results = self._process_search_results(results, filters)
        
        return {
            "query": query,
            "total_results": len(processed_results),
            "results": processed_results,
            "filters_applied": filters or {}
        }
    
    def _process_search_results(self, chroma_results: Dict, filters: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Procesa los resultados de ChromaDB y aplica filtros adicionales"""
        results = []
        
        if not chroma_results["ids"] or not chroma_results["ids"][0]:
            return results
        
        for i, doc_id in enumerate(chroma_results["ids"][0]):
            metadata = chroma_results["metadatas"][0][i]
            document = chroma_results["documents"][0][i]
            distance = chroma_results["distances"][0][i]
            
            # Aplicar filtros adicionales que no pueden hacerse en ChromaDB
            if filters:
                # Filtro por rango de fechas
                if "fecha_range" in filters and metadata.get("fecha"):
                    fecha_result = metadata["fecha"]
                    fecha_inicio = filters["fecha_range"].get("inicio")
                    fecha_fin = filters["fecha_range"].get("fin")
                    
                    if fecha_inicio and fecha_result < fecha_inicio:
                        continue
                    if fecha_fin and fecha_result > fecha_fin:
                        continue
                
                # Filtro por IF SJR mínimo
                if "min_if_sjr" in filters and metadata.get("if_sjr"):
                    try:
                        if_sjr = float(metadata["if_sjr"])
                        if if_sjr < filters["min_if_sjr"]:
                            continue
                    except (ValueError, TypeError):
                        continue
            
            # Calcular score de relevancia (1 - distancia normalizada)
            relevance_score = max(0, 1 - distance)
            
            # Crear resultado procesado
            result = {
                "id": doc_id,
                "relevance_score": round(relevance_score, 3),
                "distance": round(distance, 3),
                "content": document,
                "metadata": metadata,
                "profesor": metadata.get("profesor", "Unknown"),
                "titulo": metadata.get("titulo", ""),
                "tipo": metadata.get("tipo", ""),
                "tipo_produccion": metadata.get("tipo_produccion", ""),
                "fecha": metadata.get("fecha", ""),
                "categorias": metadata.get("categorias", ""),
                "fuente": metadata.get("fuente", ""),
                "if_sjr": metadata.get("if_sjr", ""),
                "q_sjr": metadata.get("q_sjr", "")
            }
            
            results.append(result)
        
        # Ordenar por relevancia
        results.sort(key=lambda x: x["relevance_score"], reverse=True)
        
        return results
    
    def get_all_profesores(self) -> Dict[str, Any]:
        """Obtiene todos los profesores únicos con estadísticas"""
        # Obtener todos los documentos
        all_results = self.collection.get(
            include=["metadatas"]
        )
        
        profesores_data = {}
        
        for metadata in all_results["metadatas"]:
            profesor = metadata.get("profesor")
            if not profesor:
                continue
            
            if profesor not in profesores_data:
                profesores_data[profesor] = {
                    "name": profesor,
                    "username": metadata.get("profesor_username", ""),
                    "total_works": 0,
                    "work_types": {},
                    "categories": set(),
                    "recent_works": []
                }
            
            # Actualizar estadísticas
            profesores_data[profesor]["total_works"] += 1
            
            tipo_prod = metadata.get("tipo_produccion", "Unknown")
            profesores_data[profesor]["work_types"][tipo_prod] = \
                profesores_data[profesor]["work_types"].get(tipo_prod, 0) + 1
            
            if metadata.get("categorias"):
                profesores_data[profesor]["categories"].add(metadata["categorias"])
        
        # Convertir sets a listas para serialización JSON
        for profesor_data in profesores_data.values():
            profesor_data["categories"] = list(profesor_data["categories"])
        
        # Ordenar por número de trabajos
        sorted_profesores = sorted(
            profesores_data.values(),
            key=lambda x: x["total_works"],
            reverse=True
        )
        
        return {
            "total_profesores": len(sorted_profesores),
            "profesores": sorted_profesores
        }
    
    def get_profesor_profile(self, profesor_name: str) -> Dict[str, Any]:
        """Obtiene el perfil completo de un profesor"""
        # Buscar todos los trabajos del profesor
        results = self.collection.get(
            where={"profesor": profesor_name},
            include=["metadatas", "documents"]
        )
        
        if not results["ids"]:
            return None
        
        # Procesar trabajos
        works = []
        estadisticas = {
            "total_trabajos": len(results["ids"]),
            "tipos_produccion": {},
            "años_activo": set(),
            "categorias": set(),
            "fuentes": set(),
            "trabajos_recientes": [],
            "docencia": [],
            "investigacion": [],
            "proyectos": []
        }
        
        for i, doc_id in enumerate(results["ids"]):
            metadata = results["metadatas"][i]
            document = results["documents"][i]
            
            work = {
                "id": doc_id,
                "titulo": metadata.get("titulo", ""),
                "tipo": metadata.get("tipo", ""),
                "tipo_produccion": metadata.get("tipo_produccion", ""),
                "fecha": metadata.get("fecha", ""),
                "categorias": metadata.get("categorias", ""),
                "fuente": metadata.get("fuente", ""),
                "if_sjr": metadata.get("if_sjr", ""),
                "q_sjr": metadata.get("q_sjr", ""),
                "content": document
            }
            works.append(work)
            
            # Actualizar estadísticas
            tipo_prod = metadata.get("tipo_produccion", "Unknown")
            estadisticas["tipos_produccion"][tipo_prod] = \
                estadisticas["tipos_produccion"].get(tipo_prod, 0) + 1
            
            if metadata.get("fecha"):
                try:
                    year = metadata["fecha"][:4]
                    estadisticas["años_activo"].add(year)
                except:
                    pass
            
            if metadata.get("categorias"):
                estadisticas["categorias"].add(metadata["categorias"])
            
            if metadata.get("fuente"):
                estadisticas["fuentes"].add(metadata["fuente"])
            
            # Clasificar por tipo
            if "docencia" in tipo_prod.lower():
                estadisticas["docencia"].append(work)
            elif "proyecto" in tipo_prod.lower():
                estadisticas["proyectos"].append(work)
            else:
                estadisticas["investigacion"].append(work)
        
        # Ordenar trabajos por fecha (más recientes primero)
        works.sort(key=lambda x: x["fecha"] or "", reverse=True)
        
        # Obtener trabajos más recientes
        estadisticas["trabajos_recientes"] = works[:10]
        
        # Convertir sets a listas
        estadisticas["años_activo"] = sorted(list(estadisticas["años_activo"]), reverse=True)
        estadisticas["categorias"] = list(estadisticas["categorias"])
        estadisticas["fuentes"] = list(estadisticas["fuentes"])
        
        return {
            "profesor": profesor_name,
            "works": works,
            "estadisticas": estadisticas
        }
    
    def get_database_stats(self) -> Dict[str, Any]:
        """Obtiene estadísticas generales de la base de datos"""
        all_data = self.collection.get(
            include=["metadatas"]
        )
        
        if not all_data["ids"]:
            return {
                "total_documents": 0,
                "total_profesores": 0,
                "tipos_produccion": {},
                "años_cubiertos": [],
                "categorias_populares": {}
            }
        
        # Calcular estadísticas
        tipos_produccion = {}
        años = set()
        categorias = {}
        profesores = set()
        
        for metadata in all_data["metadatas"]:
            # Contar tipos de producción
            tipo_prod = metadata.get("tipo_produccion", "Unknown")
            tipos_produccion[tipo_prod] = tipos_produccion.get(tipo_prod, 0) + 1
            
            # Años
            if metadata.get("fecha"):
                try:
                    year = metadata["fecha"][:4]
                    años.add(year)
                except:
                    pass
            
            # Categorías
            categoria = metadata.get("categorias", "Unknown")
            categorias[categoria] = categorias.get(categoria, 0) + 1
            
            # Profesores
            if metadata.get("profesor"):
                profesores.add(metadata["profesor"])
        
        return {
            "total_documents": len(all_data["ids"]),
            "total_profesores": len(profesores),
            "tipos_produccion": dict(sorted(tipos_produccion.items(), 
                                          key=lambda x: x[1], reverse=True)),
            "años_cubiertos": sorted(list(años), reverse=True),
            "categorias_populares": dict(sorted(categorias.items(), 
                                              key=lambda x: x[1], reverse=True)[:10])
        }