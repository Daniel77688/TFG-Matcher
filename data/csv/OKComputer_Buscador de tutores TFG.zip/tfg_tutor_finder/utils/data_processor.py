import csv
import uuid
from pathlib import Path
from typing import List, Dict, Any, Tuple
import pandas as pd
from sentence_transformers import SentenceTransformer
import chromadb
from chromadb.config import Settings
from config import CSV_DIR, CHROMA_DIR, COLLECTION_NAME, EMBEDDING_MODEL, RELEVANT_FIELDS

class DataProcessor:
    def __init__(self):
        self.model = SentenceTransformer(EMBEDDING_MODEL)
        self.client = chromadb.PersistentClient(
            path=str(CHROMA_DIR),
            settings=Settings(anonymized_telemetry=False)
        )
        
    def process_csv_file(self, csv_path: Path) -> List[Dict[str, Any]]:
        """Procesa un archivo CSV y extrae la información relevante"""
        documents = []
        
        try:
            with open(csv_path, 'r', newline='', encoding='utf-8') as f:
                reader = csv.DictReader(f, delimiter=';')
                for row_num, row in enumerate(reader):
                    # Limpiar las claves y valores
                    cleaned_row = {}
                    for key, value in row.items():
                        if key:
                            cleaned_key = key.strip().upper()
                            cleaned_row[cleaned_key] = (value or "").strip()
                    
                    # Extraer información relevante
                    doc_data = self._extract_relevant_info(cleaned_row, csv_path, row_num)
                    if doc_data:
                        documents.append(doc_data)
                        
        except UnicodeDecodeError:
            # Intentar con latin-1 si utf-8 falla
            with open(csv_path, 'r', newline='', encoding='latin-1') as f:
                reader = csv.DictReader(f, delimiter=';')
                for row_num, row in enumerate(reader):
                    cleaned_row = {}
                    for key, value in row.items():
                        if key:
                            cleaned_key = key.strip().upper()
                            cleaned_row[cleaned_key] = (value or "").strip()
                    
                    doc_data = self._extract_relevant_info(cleaned_row, csv_path, row_num)
                    if doc_data:
                        documents.append(doc_data)
        
        return documents
    
    def _extract_relevant_info(self, row: Dict[str, str], csv_path: Path, row_num: int) -> Dict[str, Any]:
        """Extrae la información relevante de una fila CSV"""
        # Obtener nombre del profesor del nombre del archivo
        profesor_name = csv_path.stem.replace("_", " ").title()
        
        # Crear texto semántico con los campos relevantes
        semantic_text = self._build_semantic_text(row)
        
        if not semantic_text.strip():
            return None
            
        # Crear metadatos
        metadata = {
            "profesor": profesor_name,
            "profesor_username": profesor_name.lower().replace(" ", "."),
            "titulo": row.get("TÍTULO", ""),
            "autores": row.get("AUTORES", ""),
            "fecha": row.get("FECHA", ""),
            "tipo": row.get("TIPO", ""),
            "tipo_produccion": row.get("TIPO DE PRODUCCIÓN", ""),
            "categorias": row.get("CATEGORÍAS", ""),
            "fuente": row.get("FUENTE", ""),
            "if_sjr": row.get("IF SJR", ""),
            "q_sjr": row.get("Q SJR", ""),
            "csv_file": csv_path.name,
            "row_number": row_num
        }
        
        return {
            "id": str(uuid.uuid4()),
            "text": semantic_text,
            "metadata": metadata,
            "profesor": profesor_name
        }
    
    def _build_semantic_text(self, row: Dict[str, str]) -> str:
        """Construye el texto semántico para embeddings"""
        parts = []
        
        # Título
        if row.get("TÍTULO"):
            parts.append(f"Título: {row['TÍTULO']}")
        
        # Autores
        if row.get("AUTORES"):
            parts.append(f"Autores: {row['AUTORES']}")
        
        # Tipo y tipo de producción
        if row.get("TIPO"):
            parts.append(f"Tipo: {row['TIPO']}")
        
        if row.get("TIPO DE PRODUCCIÓN"):
            parts.append(f"Tipo de producción: {row['TIPO DE PRODUCCIÓN']}")
        
        # Categorías
        if row.get("CATEGORÍAS"):
            parts.append(f"Categorías: {row['CATEGORÍAS']}")
        
        # Fuente e impacto
        if row.get("FUENTE"):
            parts.append(f"Fuente: {row['FUENTE']}")
        
        if row.get("IF SJR"):
            parts.append(f"Impacto SJR: {row['IF SJR']}")
        
        if row.get("Q SJR"):
            parts.append(f"Cuartil SJR: {row['Q SJR']}")
        
        return " ".join(parts)
    
    def load_all_csvs(self) -> Tuple[List[str], List[str], List[Dict], List[List[float]]]:
        """Carga todos los CSV y retorna los datos para ChromaDB"""
        ids, documents, metadatas, embeddings = [], [], [], []
        
        csv_files = list(CSV_DIR.glob("*.csv"))
        print(f"📦 Procesando {len(csv_files)} archivos CSV...")
        
        for csv_file in csv_files:
            print(f"  📄 Procesando: {csv_file.name}")
            docs = self.process_csv_file(csv_file)
            
            for doc in docs:
                # Generar embedding
                embedding = self.model.encode(doc["text"]).tolist()
                
                ids.append(doc["id"])
                documents.append(doc["text"])
                metadatas.append(doc["metadata"])
                embeddings.append(embedding)
        
        return ids, documents, metadatas, embeddings
    
    def setup_chroma_collection(self):
        """Configura la colección de ChromaDB"""
        try:
            self.client.delete_collection(COLLECTION_NAME)
            print(f"🗑️ Colección '{COLLECTION_NAME}' eliminada")
        except:
            print(f"ℹ️ Colección '{COLLECTION_NAME}' no existía")
        
        collection = self.client.create_collection(
            name=COLLECTION_NAME,
            metadata={
                "description": "Base de datos de profesores URJC para búsqueda de TFG",
                "model": EMBEDDING_MODEL
            }
        )
        
        return collection
    
    def load_data_to_chroma(self, batch_size: int = 1000):
        """Carga todos los datos a ChromaDB"""
        # Obtener datos
        ids, documents, metadatas, embeddings = self.load_all_csvs()
        
        if not ids:
            print("❌ No se encontraron datos para cargar")
            return
        
        # Configurar colección
        collection = self.setup_chroma_collection()
        
        # Cargar en lotes
        print(f"💾 Cargando {len(ids)} documentos en lotes de {batch_size}...")
        
        for i in range(0, len(ids), batch_size):
            batch_end = min(i + batch_size, len(ids))
            batch_num = i // batch_size + 1
            
            print(f"  📦 Lote {batch_num}: {i+1}-{batch_end}")
            
            collection.add(
                ids=ids[i:batch_end],
                documents=documents[i:batch_end],
                metadatas=metadatas[i:batch_end],
                embeddings=embeddings[i:batch_end]
            )
        
        print(f"✅ Carga completada. Total documentos: {collection.count()}")
        return collection

# Función auxiliar para cargar la colección existente
def get_chroma_collection():
    """Obtiene la colección de ChromaDB existente"""
    client = chromadb.PersistentClient(
        path=str(CHROMA_DIR),
        settings=Settings(anonymized_telemetry=False)
    )
    
    try:
        return client.get_collection(COLLECTION_NAME)
    except:
        print(f"❌ La colección '{COLLECTION_NAME}' no existe. Ejecuta load_data_to_chroma() primero.")
        return None