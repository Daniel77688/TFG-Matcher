#!/usr/bin/env python3
"""
Script para verificar que la instalación de TFG Finder está completa
"""

import sys
import os
from pathlib import Path
import importlib.util

def check_python_version():
    """Verificar versión de Python"""
    print("🐍 Verificando Python...")
    version = sys.version_info
    if version.major >= 3 and version.minor >= 8:
        print(f"✅ Python {version.major}.{version.minor}.{version.micro} - OK")
        return True
    else:
        print(f"❌ Python {version.major}.{version.minor}.{version.micro} - Requiere Python 3.8+")
        return False

def check_dependencies():
    """Verificar dependencias instaladas"""
    print("\n📦 Verificando dependencias...")
    
    required_packages = [
        'fastapi', 'uvicorn', 'chromadb', 'sentence_transformers',
        'pandas', 'numpy', 'jinja2', 'aiofiles'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            spec = importlib.util.find_spec(package)
            if spec is not None:
                print(f"✅ {package} - OK")
            else:
                print(f"❌ {package} - No instalado")
                missing_packages.append(package)
        except ImportError:
            print(f"❌ {package} - No instalado")
            missing_packages.append(package)
    
    return len(missing_packages) == 0, missing_packages

def check_directories():
    """Verificar estructura de directorios"""
    print("\n📁 Verificando directorios...")
    
    required_dirs = [
        'app', 'utils', 'templates', 'static', 'data', 'data/csv'
    ]
    
    missing_dirs = []
    
    for dir_path in required_dirs:
        path = Path(dir_path)
        if path.exists():
            print(f"✅ {dir_path}/ - OK")
        else:
            print(f"❌ {dir_path}/ - No existe")
            missing_dirs.append(dir_path)
    
    return len(missing_dirs) == 0, missing_dirs

def check_csv_files():
    """Verificar archivos CSV"""
    print("\n📄 Verificando archivos CSV...")
    
    csv_dir = Path("data/csv")
    if not csv_dir.exists():
        print("❌ Directorio data/csv/ no existe")
        return False, 0
    
    csv_files = list(csv_dir.glob("*.csv"))
    count = len(csv_files)
    
    if count == 0:
        print("❌ No se encontraron archivos CSV")
        return False, 0
    else:
        print(f"✅ Encontrados {count} archivos CSV")
        
        # Verificar algunos archivos
        sample_files = csv_files[:3]
        for csv_file in sample_files:
            try:
                with open(csv_file, 'r', encoding='utf-8') as f:
                    first_line = f.readline()
                    if 'TÍTULO' in first_line.upper():
                        print(f"  ✅ {csv_file.name} - Formato válido")
                    else:
                        print(f"  ⚠️  {csv_file.name} - Verificar formato")
            except Exception as e:
                print(f"  ⚠️  {csv_file.name} - Error al leer: {e}")
        
        return True, count

def check_chroma_db():
    """Verificar base de datos ChromaDB"""
    print("\n🗄️  Verificando ChromaDB...")
    
    chroma_dir = Path("chroma_db")
    if chroma_dir.exists():
        try:
            # Intentar importar y conectar
            import chromadb
            from chromadb.config import Settings
            
            client = chromadb.PersistentClient(
                path=str(chroma_dir),
                settings=Settings(anonymized_telemetry=False)
            )
            
            # Intentar obtener la colección
            try:
                collection = client.get_collection("profesores_tfg")
                count = collection.count()
                print(f"✅ ChromaDB encontrada con {count} documentos")
                return True, count
            except Exception as e:
                print(f"⚠️  ChromaDB existe pero no tiene datos cargados")
                print(f"   Ejecuta: python data_loader.py")
                return False, 0
                
        except ImportError:
            print("❌ ChromaDB no está instalado")
            return False, 0
        except Exception as e:
            print(f"❌ Error al verificar ChromaDB: {e}")
            return False, 0
    else:
        print("❌ ChromaDB no existe")
        print("   Ejecuta: python data_loader.py")
        return False, 0

def check_templates():
    """Verificar plantillas HTML"""
    print("\n📝 Verificando plantillas...")
    
    required_templates = [
        'base.html', 'index.html', 'search.html', 
        'profesor.html', 'about.html'
    ]
    
    templates_dir = Path("templates")
    missing_templates = []
    
    if templates_dir.exists():
        for template in required_templates:
            template_path = templates_dir / template
            if template_path.exists():
                print(f"✅ {template} - OK")
            else:
                print(f"❌ {template} - No existe")
                missing_templates.append(template)
    else:
        print("❌ Directorio templates/ no existe")
        return False, []
    
    return len(missing_templates) == 0, missing_templates

def main():
    """Función principal de verificación"""
    print("🔍 Verificando instalación de TFG Finder")
    print("=" * 50)
    
    all_good = True
    
    # Verificaciones
    python_ok = check_python_version()
    all_good = all_good and python_ok
    
    deps_ok, missing_deps = check_dependencies()
    all_good = all_good and deps_ok
    
    dirs_ok, missing_dirs = check_directories()
    all_good = all_good and dirs_ok
    
    csv_ok, csv_count = check_csv_files()
    all_good = all_good and csv_ok
    
    chroma_ok, doc_count = check_chroma_db()
    all_good = all_good and chroma_ok
    
    templates_ok, missing_templates = check_templates()
    all_good = all_good and templates_ok
    
    # Resumen
    print("\n" + "=" * 50)
    print("📋 RESUMEN DE VERIFICACIÓN")
    print("=" * 50)
    
    if all_good:
        print("🎉 ¡Todo está listo!")
        print("\n✅ Puedes iniciar la aplicación con:")
        print("   python run.py")
        print("\n🌐 La aplicación estará disponible en:")
        print("   http://localhost:8000")
    else:
        print("⚠️  Se encontraron algunos problemas:")
        
        if missing_deps:
            print(f"\n📦 Dependencias faltantes: {', '.join(missing_deps)}")
            print("   Instala con: pip install -r requirements.txt")
        
        if missing_dirs:
            print(f"\n📁 Directorios faltantes: {', '.join(missing_dirs)}")
        
        if csv_count == 0:
            print("\n📄 No se encontraron archivos CSV")
            print("   Coloca los archivos CSV en: data/csv/")
        
        if not chroma_ok:
            print("\n🗄️  Base de datos no inicializada")
            print("   Ejecuta: python data_loader.py")
        
        if missing_templates:
            print(f"\n📝 Plantillas faltantes: {', '.join(missing_templates)}")
    
    return all_good

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)