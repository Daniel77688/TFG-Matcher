from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse, JSONResponse
from typing import List, Optional, Dict, Any
import uvicorn
from pathlib import Path
import json

from config import STATIC_DIR, TEMPLATES_DIR, API_HOST, API_PORT
from utils.search_engine import SearchEngine
from utils.data_processor import get_chroma_collection

# Crear aplicación FastAPI
app = FastAPI(
    title="Buscador de Tutores TFG - URJC",
    description="Encuentra el mejor tutor para tu TFG usando búsqueda semántica",
    version="1.0.0"
)

# Montar archivos estáticos
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

# Configurar templates
templates = Jinja2Templates(directory=TEMPLATES_DIR)

# Inicializar motor de búsqueda
search_engine = None

@app.on_event("startup")
async def startup_event():
    """Inicializar recursos al iniciar la aplicación"""
    global search_engine
    collection = get_chroma_collection()
    if collection:
        search_engine = SearchEngine(collection)
        print("✅ Motor de búsqueda inicializado")
    else:
        print("❌ No se pudo inicializar el motor de búsqueda. Ejecuta data_loader.py primero.")

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    """Página principal"""
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/search")
async def search(
    query: str = Query(..., description="Consulta de búsqueda"),
    limit: int = Query(10, ge=1, le=50, description="Número de resultados"),
    profesor: Optional[str] = Query(None, description="Filtrar por profesor"),
    tipo_produccion: Optional[str] = Query(None, description="Filtrar por tipo de producción"),
    fecha_inicio: Optional[str] = Query(None, description="Fecha inicio (YYYY-MM-DD)"),
    fecha_fin: Optional[str] = Query(None, description="Fecha fin (YYYY-MM-DD)"),
    categoria: Optional[str] = Query(None, description="Filtrar por categoría"),
    min_if_sjr: Optional[float] = Query(None, description="IF SJR mínimo"),
    q_sjr: Optional[str] = Query(None, description="Cuartil SJR (Q1, Q2, Q3, Q4)")
):
    """Endpoint de búsqueda con filtros"""
    if not search_engine:
        raise HTTPException(
            status_code=503,
            detail="Servicio no disponible. La base de datos no está inicializada."
        )
    
    try:
        # Construir filtros
        filters = {}
        if profesor:
            filters["profesor"] = profesor
        if tipo_produccion:
            filters["tipo_produccion"] = tipo_produccion
        if fecha_inicio or fecha_fin:
            filters["fecha_range"] = {
                "inicio": fecha_inicio,
                "fin": fecha_fin
            }
        if categoria:
            filters["categoria"] = categoria
        if min_if_sjr:
            filters["min_if_sjr"] = min_if_sjr
        if q_sjr:
            filters["q_sjr"] = q_sjr
        
        # Realizar búsqueda
        results = search_engine.search(
            query=query,
            limit=limit,
            filters=filters
        )
        
        return JSONResponse(content=results)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error en la búsqueda: {str(e)}")

@app.get("/profesores")
async def get_profesores():
    """Obtener lista de todos los profesores"""
    if not search_engine:
        raise HTTPException(
            status_code=503,
            detail="Servicio no disponible"
        )
    
    try:
        profesores = search_engine.get_all_profesores()
        return JSONResponse(content=profesores)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error obteniendo profesores: {str(e)}")

@app.get("/profesor/{profesor_name}")
async def get_profesor_profile(profesor_name: str):
    """Obtener perfil completo de un profesor"""
    if not search_engine:
        raise HTTPException(
            status_code=503,
            detail="Servicio no disponible"
        )
    
    try:
        profile = search_engine.get_profesor_profile(profesor_name)
        if not profile:
            raise HTTPException(status_code=404, detail="Profesor no encontrado")
        
        return JSONResponse(content=profile)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error obteniendo perfil: {str(e)}")

@app.get("/stats")
async def get_stats():
    """Obtener estadísticas de la base de datos"""
    if not search_engine:
        raise HTTPException(
            status_code=503,
            detail="Servicio no disponible"
        )
    
    try:
        stats = search_engine.get_database_stats()
        return JSONResponse(content=stats)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error obteniendo estadísticas: {str(e)}")

@app.get("/tipos-produccion")
async def get_tipos_produccion():
    """Obtener tipos de producción disponibles"""
    from config import TIPOS_PRODUCCION
    return JSONResponse(content=TIPOS_PRODUCCION)

@app.get("/search-page", response_class=HTMLResponse)
async def search_page(request: Request):
    """Página de búsqueda"""
    return templates.TemplateResponse("search.html", {"request": request})

@app.get("/profesor-page/{profesor_name}", response_class=HTMLResponse)
async def profesor_page(request: Request, profesor_name: str):
    """Página de perfil de profesor"""
    return templates.TemplateResponse("profesor.html", {
        "request": request,
        "profesor_name": profesor_name
    })

@app.get("/about", response_class=HTMLResponse)
async def about_page(request: Request):
    """Página acerca de"""
    return templates.TemplateResponse("about.html", {"request": request})

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host=API_HOST,
        port=API_PORT,
        reload=API_RELOAD
    )