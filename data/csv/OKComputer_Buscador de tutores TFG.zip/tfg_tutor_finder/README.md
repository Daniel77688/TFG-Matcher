# TFG Finder - Buscador de Tutores para TFG

![TFG Finder](https://img.shields.io/badge/TFG-Finder-red)
![Python](https://img.shields.io/badge/Python-3.8+-blue)
![FastAPI](https://img.shields.io/badge/FastAPI-0.104.1-green)
![ChromaDB](https://img.shields.io/badge/ChromaDB-0.4.15-orange)

## 📋 Descripción

TFG Finder es una aplicación web inteligente que ayuda a estudiantes de la Universidad Rey Juan Carlos a encontrar el mejor tutor para su Trabajo de Fin de Grado (TFG). Utiliza inteligencia artificial y búsqueda semántica para analizar la producción académica de los profesores y proporcionar recomendaciones personalizadas.

## ✨ Características Principales

- 🔍 **Búsqueda Semántica**: Encuentra tutores basándose en el significado y contexto de tu consulta
- 🎯 **Filtros Avanzados**: Filtra por tipo de producción, años de experiencia, áreas de conocimiento, etc.
- 📊 **Perfiles Detallados**: Visualiza estadísticas completas de cada profesor
- 🤖 **IA Avanzada**: Utiliza modelos de embeddings para búsquedas precisas
- 📱 **Interfaz Moderna**: Diseño responsivo y atractivo con animaciones
- ⚡ **Rendimiento**: Búsquedas rápidas con ChromaDB y FastAPI

## 🛠️ Tecnologías Utilizadas

- **Backend**: FastAPI (Python)
- **Base de Datos**: ChromaDB (vectorial)
- **IA/ML**: Sentence Transformers, embeddings semánticos
- **Frontend**: HTML5, CSS3, JavaScript (Alpine.js)
- **Estilos**: Tailwind CSS
- **Íconos**: Font Awesome

## 📦 Requisitos Previos

- Python 3.8 o superior
- pip (gestor de paquetes de Python)
- 169 archivos CSV con datos de profesores (formato específico)
- 2-4 GB de RAM libre
- Conexión a internet (para descargas iniciales)

## 🚀 Instalación

### 1. Clonar el Repositorio

```bash
git clone https://github.com/tu-usuario/tfg-finder.git
cd tfg-finder
```

### 2. Crear Entorno Virtual

```bash
# Crear entorno virtual
python -m venv venv

# Activar entorno virtual
# En Windows:
venv\Scripts\activate
# En Linux/Mac:
source venv/bin/activate
```

### 3. Instalar Dependencias

```bash
pip install -r requirements.txt
```

### 4. Configurar el Entorno

```bash
# Copiar archivo de configuración de ejemplo
cp .env.example .env

# Editar .env según tus necesidades (opcional)
```

### 5. Preparar los Datos

**IMPORTANTE**: Antes de ejecutar la aplicación, necesitas los datos de los profesores:

1. Crea la carpeta `data/csv/` si no existe:
   ```bash
   mkdir -p data/csv
   ```

2. Copia todos tus archivos CSV (169 archivos) en la carpeta `data/csv/`

3. Verifica que los archivos tengan el formato correcto:
   - Nombre: `Apellidos_Nombre.csv`
   - Codificación: UTF-8 o Latin-1
   - Delimitador: `;`
   - Columnas requeridas: TÍTULO, AUTORES, FECHA, TIPO, TIPO DE PRODUCCIÓN, etc.

### 6. Cargar Datos en la Base de Datos

```bash
# Cargar todos los CSV en ChromaDB
python data_loader.py
```

Este proceso puede tardar varios minutos dependiendo de la cantidad de datos.

## 🎯 Uso

### Iniciar la Aplicación

```bash
# Método 1: Usando el script principal
python run.py

# Método 2: Usando uvicorn directamente
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

### Acceder a la Aplicación

Una vez iniciado el servidor, abre tu navegador y visita:

- **Aplicación Web**: `http://localhost:8000`
- **Documentación API**: `http://localhost:8000/docs`
- **Documentación Alternativa**: `http://localhost:8000/redoc`

### Rutas Principales

- `/` - Página principal con información general
- `/search-page` - Interfaz de búsqueda de tutores
- `/profesor-page/{nombre}` - Perfil detallado de un profesor
- `/about` - Información sobre la aplicación
- `/api/search` - API de búsqueda (GET)
- `/api/profesores` - API para obtener lista de profesores
- `/api/stats` - API para obtener estadísticas

## 📊 Estructura del Proyecto

```
tfg-finder/
├── app/
│   └── main.py              # Aplicación FastAPI principal
├── utils/
│   ├── data_processor.py    # Procesamiento de CSV y ChromaDB
│   └── search_engine.py     # Motor de búsqueda semántica
├── templates/
│   ├── base.html           # Plantilla base
│   ├── index.html          # Página principal
│   ├── search.html         # Página de búsqueda
│   ├── profesor.html       # Perfil de profesor
│   └── about.html          # Acerca de
├── static/
│   ├── css/                # Estilos CSS
│   ├── js/                 # JavaScript
│   └── images/             # Imágenes
├── data/
│   └── csv/                # Archivos CSV de profesores
├── chroma_db/              # Base de datos ChromaDB
├── config.py               # Configuración de la aplicación
├── data_loader.py          # Script de carga de datos
├── run.py                  # Script principal
├── requirements.txt        # Dependencias Python
├── .env.example           # Ejemplo de configuración
└── README.md              # Este archivo
```

## 🔍 Uso de la API

### Búsqueda de Tutores

```http
GET /search?query=machine learning&limit=10&tipo_produccion=Artículo
```

**Parámetros:**
- `query` (requerido): Consulta de búsqueda
- `limit`: Número de resultados (1-50, por defecto: 10)
- `tipo_produccion`: Filtrar por tipo de producción
- `q_sjr`: Filtrar por cuartil SJR (Q1, Q2, Q3, Q4)
- `min_if_sjr`: IF SJR mínimo
- `fecha_inicio`: Fecha de inicio (YYYY-MM-DD)
- `fecha_fin`: Fecha de fin (YYYY-MM-DD)

### Obtener Perfil de Profesor

```http
GET /profesor/{nombre_profesor}
```

### Obtener Estadísticas

```http
GET /stats
```

## 🎨 Personalización

### Colores y Estilos

La aplicación utiliza una paleta de colores rojo/blanco/negro. Para modificar los colores:

1. Edita los CSS custom en `templates/base.html`
2. Modifica las variables CSS:
   ```css
   :root {
       --primary-red: #dc2626;
       --dark-red: #991b1b;
       --light-red: #fca5a5;
   }
   ```

### Configuración de Modelos

Para cambiar el modelo de embeddings, edita `config.py`:

```python
EMBEDDING_MODEL = 'all-MiniLM-L6-v2'  # Cambiar por otro modelo de Sentence Transformers
```

## 🐛 Solución de Problemas

### Error: "No se encontraron archivos CSV"

```bash
# Verificar que los archivos existen
ls -la data/csv/

# Si no existen, crear el directorio y copiar los archivos
mkdir -p data/csv
# Copia tus archivos CSV aquí
```

### Error: "La colección no existe"

```bash
# Ejecutar el cargador de datos primero
python data_loader.py
```

### Error de memoria al cargar datos

```bash
# Reducir el tamaño del lote en data_loader.py
# Cambiar batch_size de 1000 a 500 o menos
```

### Error de codificación de caracteres

```bash
# Los archivos CSV deben estar en UTF-8 o Latin-1
# Convertir si es necesario:
iconv -f original_encoding -t utf-8 file.csv > file_utf8.csv
```

## 📈 Rendimiento

- **Tiempo de carga inicial**: 2-5 minutos (dependiendo de los datos)
- **Tiempo de búsqueda**: < 1 segundo
- **Memoria RAM requerida**: 2-4 GB
- **Espacio en disco**: ~500 MB para base de datos

## 🔒 Seguridad

- Validación de entradas de usuario
- Protección contra inyección SQL
- Sin ejecución de código arbitrario
- CORS configurado para seguridad

## 🤝 Contribuir

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📄 Licencia

Este proyecto está desarrollado para uso académico en la Universidad Rey Juan Carlos.

## 👥 Contacto

- **Soporte Técnico**: soporte@tfgfinder.urjc.es
- **Información Académica**: academico@urjc.es
- **Proyecto**: https://github.com/tu-usuario/tfg-finder

## 🙏 Agradecimientos

- Universidad Rey Juan Carlos por el apoyo
- Equipo de desarrollo de TFG Finder
- Comunidad open source por las herramientas utilizadas

---

**Desarrollado con ❤️ para la comunidad académica de la URJC**